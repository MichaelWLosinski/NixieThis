# Simple script to remove namespace attributes unwanted by the examples section

import xml.dom.minidom

ifnames = ['16_01_08_EndDeviceControl.xml',
'16_01_10_Registration.xml',
'16_02_08_EndDeviceList.xml',
'16_02_10_EndDevice.xml',
'16_03_06_EndDevice.xml',
'16_03_11_FunctionSetAssignmentsList.xml',
'16_04_06_EndDevice.xml',
'16_04_11_DeviceCapability.xml',
'16_06_01_Subscription.xml',
'16_06_04_Notification.xml',
'16_07_03_DemandResponseProgramList.xml',
'16_07_05_EndDeviceControlList.xml',
'16_07_06_Response.xml',
'16_07_09_Response.xml',
'16_07_12_Response.xml',
'16_08_12_EndDeviceControl.xml',
'16_08_14_Response.xml',
'16_09_03_DERProgramList.xml',
'16_09_05_Subscription.xml',
'16_09_08_DERControlList.xml',
'16_09_12_DERCurveList.xml',
'16_09_13_Response.xml',
'16_09_16_Response.xml',
'16_09_19_Response.xml',
'16_10_02_UsagePointList.xml',
'16_10_04_MeterReadingList.xml',
'16_10_06_ReadingType.xml',
'16_10_08_ReadingSetList.xml',
'16_10_10_ReadingList.xml',
'16_11_02_UsagePointList.xml',
'16_11_04_MeterReadingList.xml',
'16_11_06_ReadingType.xml',
'16_11_08_ReadingSetList.xml',
'16_11_10_ReadingList.xml',
'16_12_02_UsagePointList.xml',
'16_12_04_MeterReadingList.xml',
'16_12_06_ReadingType.xml',
'16_12_08_Reading.xml',
'16_13_01_MirrorUsagePoint.xml',
'16_13_03_MirrorMeterReading.xml',
'16_14_02_TariffProfile.xml',
'16_14_04_RateComponentList.xml',
'16_14_06_ReadingType.xml',
'16_14_08_TimeTariffIntervalList.xml',
'16_14_10_ConsumptionTariffIntervalList.xml',
'16_15_02_CustomerAccount.xml',
'16_15_04_ServiceSupplier.xml',
'16_15_06_CustomerAgreementList.xml',
'16_15_08_BillingPeriodList.xml',
'16_16_02_HistoricalReadingList.xml',
'16_16_04_ReadingType.xml',
'16_16_06_BillingReadingSetList.xml',
'16_16_08_BillingReadingList.xml',
'16_17_02_ProjectionReadingList.xml',
'16_17_04_ReadingType.xml',
'16_17_06_BillingReadingSetList.xml',
'16_17_08_BillingReadingList.xml',
'16_18_04_FileList.xml',
'16_18_10_File.xml',
'16_19_01_FlowReservationRequest.xml',
'16_19_04_FlowReservationResponseList.xml',
'16_19_06_FlowReservationResponseList.xml',
'16_19_07_PowerStatus.xml',
'16_20_01_FlowReservationRequest.xml',
'16_20_03_FlowReservationRequest.xml',
'16_20_05_FlowReservationRequest.xml',
'16_20_08_FlowReservationResponseList.xml']

for ifname in ifnames:
    print(ifname)
    doc = xml.dom.minidom.parse(ifname)
    if ifname != '16_06_04_Notification.xml':
        doc.documentElement.removeAttribute('xmlns:xsi')
    doc.documentElement.removeAttribute('xsi:schemaLocation')
    outstring = doc.toxml()
    ofname = '../Out/' + ifname
    #ofname = ofns[0] + '_1.' + ofns[1]
    outfile = open(ofname,'w')
    outfile.write(outstring[22:]) # Slicing is a convenient way of skipping over the "<?xml version="1.0" ?>" always produced but not needed for examples
